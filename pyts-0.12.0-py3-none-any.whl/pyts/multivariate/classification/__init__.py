from .multivariate import MultivariateClassifier

__all__ = ['MultivariateClassifier']
