from .utils import check_3d_array

__all__ = ['check_3d_array']
