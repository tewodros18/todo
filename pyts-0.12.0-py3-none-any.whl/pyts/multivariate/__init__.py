"""
The :mod:`pyts.multivariate` module includes tools to deal for multivariate
time series.
"""

__all__ = ['classification', 'image', 'transformation', 'utils']
